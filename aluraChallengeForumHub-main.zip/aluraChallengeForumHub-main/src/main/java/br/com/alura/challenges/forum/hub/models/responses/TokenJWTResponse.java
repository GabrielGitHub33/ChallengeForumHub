package br.com.alura.challenges.forum.hub.models.responses;

public record TokenJWTResponse(String token) {
}

CREATE TABLE cursos(
    id BIGINT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(128),
    categoria VARCHAR(128),

    PRIMARY KEY(id)
);

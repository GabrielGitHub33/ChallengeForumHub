package br.com.forumhub.domain.topic;

public enum Status {
    NAO_RESPONDIDO,
    RESPONDIDO,
    FECHADO
}

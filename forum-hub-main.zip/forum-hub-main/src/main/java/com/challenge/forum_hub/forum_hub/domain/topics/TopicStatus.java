package com.challenge.forum_hub.forum_hub.domain.topics;

public enum TopicStatus {
    OPEN,
    CLOSED,
    PENDING;
}
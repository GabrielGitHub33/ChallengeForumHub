//package com.challenge.forum_hub.forum_hub.domain.user;
//
//public enum ProfileUser {
//    ADMINISTRATOR,
//    USER;
//}
package com.challenge.forum_hub.forum_hub.domain.userauthentication;

public record UserAuthenticationData(String userName, String userPassword) {
}
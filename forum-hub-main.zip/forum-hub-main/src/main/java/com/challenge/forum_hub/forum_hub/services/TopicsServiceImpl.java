package com.challenge.forum_hub.forum_hub.services;


//import lombok.RequiredArgsConstructor;
//import org.springframework.stereotype.Service;
//import java.util.List;
//
//@Service
//@RequiredArgsConstructor

//public class TopicsServiceImpl implements CRUD {
// public class TopicsServiceImpl {
//
//    private final TopicsRepository repository;
//    private Long id;

//    public TopicsServiceImpl(ITopicsRepository repository) {
//        this.repository = repository;
//    }


//    @Override
//    public List<Topics> findAll() {
//        return repository.findAll();
//    }
//
//    @Override
//    public Topics findByID(Long id) {
//        return null;
//    }
//
//    @Override
//    public Topics save(Topics topicos) {
//        //return repository.findById(id).orElseThrow();
//        return null;
//    }
//
//    @Override
//    public Topics update(Long id, Topics topicos) {
//        //topicos.setId(id);
//        return repository.save(topicos);
//    }
//
//    @Override
//    public void deleteById(Long id) {
//        //repository.deleteById(id);
//
//    }
//}
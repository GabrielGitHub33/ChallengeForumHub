package com.challenge.forum_hub.forum_hub.services.security;

public record DataTokenJWT (String token) {}
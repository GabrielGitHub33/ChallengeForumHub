package com.challenge.forum_hub.forum_hub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForumHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
